#include <iostream>
#include <string>
#include <vector>
#include "HuffmanUtils.h"

static int g_fail = 0;
#define CHECK(name, cond) do { bool ok_ = (cond); \
    std::cout << (ok_ ? "[PASS] " : "[FAIL] ") << name << "\n"; if (!ok_) ++g_fail; } while (0)

int main() {
    std::cout << "HuffmanUtils version " << huff_getVersion() << "\n\n";

    const char* text = "abracadabra";
    HuffmanTree* t = huff_buildTree(text);
    CHECK("buildTree(abracadabra) != NULL", t != nullptr);

    size_t len = 0;
    CHECK("encode: size", huff_encode(t, text, nullptr, 0, &len) == HUFF_OK);
    std::vector<char> bits(len + 1);
    CHECK("encode: encoding", huff_encode(t, text, bits.data(), bits.size(), &len) == HUFF_OK);
    std::cout << "  bits (" << len << "): " << bits.data() << "\n";
    std::cout << "  ratio: " << huff_compressionRatio(text, bits.data()) << "\n";

    size_t dlen = 0;
    huff_decode(t, bits.data(), nullptr, 0, &dlen);
    std::vector<char> back(dlen + 1);
    CHECK("decode: round trip", huff_decode(t, bits.data(), back.data(), back.size(), &dlen) == HUFF_OK
                                && std::string(back.data()) == text);

    CHECK("buildTree(NULL) == NULL", huff_buildTree(nullptr) == nullptr);
    CHECK("buildTree(\"\") == NULL", huff_buildTree("") == nullptr);
    CHECK("freeTree(NULL) safe", (huff_freeTree(nullptr), true));
    CHECK("encode(tree==NULL)", huff_encode(nullptr, text, nullptr, 0, &len) == HUFF_ERR_NULL_ARG);
    char small[3];
    CHECK("encode: small buffer", huff_encode(t, text, small, sizeof small, &len) == HUFF_ERR_BUFFER_TOO_SMALL);
    CHECK("encode: unknown symbol", huff_encode(t, "xyz", nullptr, 0, &len) == HUFF_ERR_UNKNOWN_SYMBOL);
    CHECK("decode: invalid bit", huff_decode(t, "01x", nullptr, 0, &len) == HUFF_ERR_INVALID_BITS);
    CHECK("decode: truncated code", huff_decode(t, "1", nullptr, 0, &len) == HUFF_ERR_INVALID_BITS);
    CHECK("ratio(NULL) == -1", huff_compressionRatio(nullptr, "01") == -1.0);
    huff_freeTree(t);

    HuffmanTree* one = huff_buildTree("aaaa");
    char b1[8]; size_t l1 = 0;
    CHECK("single symbol: code \"0\" x4", huff_encode(one, "aaaa", b1, sizeof b1, &l1) == HUFF_OK && std::string(b1) == "0000");
    huff_freeTree(one);

    std::string big(1'000'000, 'a'); for (size_t i = 0; i < big.size(); i += 7) big[i] = 'b';
    HuffmanTree* tb = huff_buildTree(big.c_str());
    size_t bl = 0; huff_encode(tb, big.c_str(), nullptr, 0, &bl);
    std::vector<char> bb(bl + 1); huff_encode(tb, big.c_str(), bb.data(), bb.size(), &bl);
    std::vector<char> db(big.size() + 1); size_t dl = 0;
    CHECK("1 MB: round trip", huff_decode(tb, bb.data(), db.data(), db.size(), &dl) == HUFF_OK && big == db.data());
    huff_freeTree(tb);

    std::cout << "\nFailed: " << g_fail << "\n";
    return g_fail ? 1 : 0;
}