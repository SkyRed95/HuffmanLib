/* HuffmanUtils.h - публічний C-інтерфейс бібліотеки (версія API 1.0) */
#ifndef HUFFMAN_UTILS_H
#define HUFFMAN_UTILS_H

#include <stddef.h>

#if defined(_WIN32)
  #if defined(HUFFMAN_STATIC)
    #define HUFFMAN_API
  #elif defined(HUFFMAN_EXPORTS)
    #define HUFFMAN_API __declspec(dllexport)
  #else
    #define HUFFMAN_API __declspec(dllimport)
  #endif
#else
  #define HUFFMAN_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Коди повернення */
#define HUFF_OK                    0
#define HUFF_ERR_NULL_ARG         -1
#define HUFF_ERR_BUFFER_TOO_SMALL -2
#define HUFF_ERR_UNKNOWN_SYMBOL   -3
#define HUFF_ERR_INVALID_BITS     -4
#define HUFF_ERR_INTERNAL         -5

/* Непрозорий дескриптор дерева Хаффмана (розмір і вміст приховані) */
typedef struct HuffmanTree HuffmanTree;

/* Рядок з версією бібліотеки, наприклад "1.0.0". Звільняти НЕ потрібно. */
HUFFMAN_API const char* huff_getVersion(void);

/* Будує дерево за частотами символів рядка text (UTF-8/ANSI, завершений '\0').
   Повертає дескриптор або NULL (text == NULL, порожній рядок, нестача пам'яті).
   Дескриптор ОБОВ'ЯЗКОВО звільнити через huff_freeTree(). */
HUFFMAN_API HuffmanTree* huff_buildTree(const char* text);

/* Звільняє дерево. Допускає NULL. Другий виклик для того самого вказівника - UB. */
HUFFMAN_API void huff_freeTree(HuffmanTree* tree);

/* Кодує text у рядок з символів '0'/'1' (завершений '\0').
   outBuf == NULL -> лише обчислює довжину в *outLen (без '\0').
   outCap - розмір outBuf у байтах, має бути >= *outLen + 1.
   Усі символи text мають бути присутні в дереві. */
HUFFMAN_API int huff_encode(const HuffmanTree* tree, const char* text,
                            char* outBuf, size_t outCap, size_t* outLen);

/* Декодує рядок бітів ('0'/'1') у текст (завершений '\0'). Семантика буфера
   така сама, як у huff_encode. */
HUFFMAN_API int huff_decode(const HuffmanTree* tree, const char* bits,
                            char* outBuf, size_t outCap, size_t* outLen);

/* Коефіцієнт стиснення = (strlen(text)*8) / strlen(bits).
   Повертає -1.0 при NULL або порожніх рядках. */
HUFFMAN_API double huff_compressionRatio(const char* text, const char* bits);

#ifdef __cplusplus
}
#endif
#endif
