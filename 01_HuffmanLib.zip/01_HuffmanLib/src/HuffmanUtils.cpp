#include "HuffmanUtils.h"

#include <array>
#include <cstring>
#include <memory>
#include <queue>
#include <string>
#include <utility>
#include <vector>

struct HuffmanTree {
    struct Node { int left = -1; int right = -1; int symbol = -1; };
    std::vector<Node> nodes;
    int root = -1;
    std::array<std::string, 256> codes;
    std::array<bool, 256> has{};
};

extern "C" {

const char* huff_getVersion(void) { return "1.0.0"; }

HuffmanTree* huff_buildTree(const char* text) {
    if (!text || !*text) return nullptr;
    try {
        size_t freq[256] = {0};
        for (const unsigned char* p = reinterpret_cast<const unsigned char*>(text); *p; ++p) ++freq[*p];

        auto tree = std::make_unique<HuffmanTree>();
        struct Item { size_t w; size_t order; int idx; };
        auto cmp = [](const Item& a, const Item& b) {
            return a.w != b.w ? a.w > b.w : a.order > b.order;   // детермінований вибір
        };
        std::priority_queue<Item, std::vector<Item>, decltype(cmp)> pq(cmp);

        size_t order = 0;
        for (int s = 0; s < 256; ++s) {
            if (!freq[s]) continue;
            tree->nodes.push_back({-1, -1, s});
            tree->has[s] = true;
            pq.push({freq[s], order++, static_cast<int>(tree->nodes.size()) - 1});
        }
        while (pq.size() > 1) {
            Item a = pq.top(); pq.pop();
            Item b = pq.top(); pq.pop();
            tree->nodes.push_back({a.idx, b.idx, -1});
            pq.push({a.w + b.w, order++, static_cast<int>(tree->nodes.size()) - 1});
        }
        tree->root = pq.top().idx;

        const auto& rootNode = tree->nodes[tree->root];
        if (rootNode.symbol >= 0) {                  // особливий випадок: один унікальний символ
            tree->codes[rootNode.symbol] = "0";
        } else {
            std::vector<std::pair<int, std::string>> st;
            st.emplace_back(tree->root, "");
            while (!st.empty()) {
                auto [idx, prefix] = std::move(st.back());
                st.pop_back();
                const auto& n = tree->nodes[idx];
                if (n.symbol >= 0) { tree->codes[n.symbol] = prefix; continue; }
                st.emplace_back(n.right, prefix + "1");
                st.emplace_back(n.left,  prefix + "0");
            }
        }
        return tree.release();
    } catch (...) {
        return nullptr;                              // виключення не перетинають межу DLL
    }
}

void huff_freeTree(HuffmanTree* tree) { delete tree; }

int huff_encode(const HuffmanTree* tree, const char* text,
                char* outBuf, size_t outCap, size_t* outLen) {
    if (!tree || !text || !outLen) return HUFF_ERR_NULL_ARG;
    *outLen = 0;
    size_t need = 0;
    for (const unsigned char* p = reinterpret_cast<const unsigned char*>(text); *p; ++p) {
        if (!tree->has[*p]) return HUFF_ERR_UNKNOWN_SYMBOL;
        need += tree->codes[*p].size();
    }
    *outLen = need;
    if (!outBuf) return HUFF_OK;
    if (outCap < need + 1) return HUFF_ERR_BUFFER_TOO_SMALL;
    size_t pos = 0;
    for (const unsigned char* p = reinterpret_cast<const unsigned char*>(text); *p; ++p) {
        const std::string& c = tree->codes[*p];
        std::memcpy(outBuf + pos, c.data(), c.size());
        pos += c.size();
    }
    outBuf[pos] = '\0';
    return HUFF_OK;
}

int huff_decode(const HuffmanTree* tree, const char* bits,
                char* outBuf, size_t outCap, size_t* outLen) {
    if (!tree || !bits || !outLen) return HUFF_ERR_NULL_ARG;
    *outLen = 0;
    try {
        const bool single = tree->nodes[tree->root].symbol >= 0;
        std::string result;
        int cur = tree->root;
        for (const char* p = bits; *p; ++p) {
            if (*p != '0' && *p != '1') return HUFF_ERR_INVALID_BITS;
            if (single) {
                if (*p != '0') return HUFF_ERR_INVALID_BITS;
                result.push_back(static_cast<char>(tree->nodes[tree->root].symbol));
                continue;
            }
            const auto& n = tree->nodes[cur];
            cur = (*p == '0') ? n.left : n.right;
            if (tree->nodes[cur].symbol >= 0) {
                result.push_back(static_cast<char>(tree->nodes[cur].symbol));
                cur = tree->root;
            }
        }
        if (!single && cur != tree->root) return HUFF_ERR_INVALID_BITS;   // обірваний код
        *outLen = result.size();
        if (!outBuf) return HUFF_OK;
        if (outCap < result.size() + 1) return HUFF_ERR_BUFFER_TOO_SMALL;
        std::memcpy(outBuf, result.c_str(), result.size() + 1);
        return HUFF_OK;
    } catch (...) {
        return HUFF_ERR_INTERNAL;
    }
}

double huff_compressionRatio(const char* text, const char* bits) {
    if (!text || !bits) return -1.0;
    size_t t = std::strlen(text), b = std::strlen(bits);
    if (t == 0 || b == 0) return -1.0;
    return (static_cast<double>(t) * 8.0) / static_cast<double>(b);
}

} // extern "C"
